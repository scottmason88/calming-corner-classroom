/* Chooses a button's colour (its Fitzgerald category) from the words on it.

   Category keys are the ones in common.js: pronoun (People), verb (Actions), describe (Describing),
   noun (Things), place (Little words), social, question, negative (No / not), neutral (Other).

   The data (words.json, made by scripts/build-words.mjs) has two parts:
     exact  every word and phrase Talk Boards already colours (templates.js, topics.json,
            checked against the classroom board) plus the core strip. These always win.
     pos    a trimmed part-of-speech list (Moby Part-of-Speech, public domain), one category per
            word from its first-listed part of speech.

   How a label is read, in order (the first rule that answers wins):
     1. The teacher's own choice for exactly these words (remembered when they pick a colour).
     2. The exact list and the social phrases, for the whole label ("no thank you" is Social).
     3. Polite endings are dropped: "scarf please" is read as "scarf".
     4. "I feel …", "I'm …", "feel …"                    → Describing (as on the feelings board).
     4b. not / don't / can't / won't / never / no anywhere in a phrase → No / not
        ("I don't like it", "I don't know").
     4c. A choice with "or" ("yes or no")                 → Questions.
     4d. Mr / Mrs / Ms / Miss / Dr + a name               → People ("Mr Lee"; "miss you" is not a name).
     6b. "I" + an action word                             → Actions ("I miss you", "I go").
     5. "I need …", "I want …", "I like …", "can I have …" → the rest of the label is read on its own,
        so "I need a break" is Things and "I need to talk" is Actions (as on the I-need board).
     6. "to …"                                            → Actions.
     7. Starts with what / where / who / when / why / how / which → Questions.
     8. Starts with not / don't / can't / won't / never / no more → No / not.
     9. Starts with too / so / very / really / all        → Describing ("too loud", "all gone").
       (Before rule 4, a short list of social phrases is checked: "good job", "uh oh", "excuse me".)
    10. One word: see `word()` below.
    11. Starts with a/an/the/my/your/some/this/that … → the rest is read on its own ("my coat").
    12. Starts with an action word                        → Actions ("put on", "take off", "wash hands").
    13. A thing and a little word ("shoes off", "lights on", "hands up") → Actions: it's asking for
        something to be done, like "lights off" on Talk Boards.
    14. Otherwise the last word decides (the head noun):  "paper towel", "party hat" → Things;
        "new teacher" → People. After a describing word, an action-looking last word is a thing
        ("little bear", "big swing").
   One word (`lookup()`): the teacher's choice, the exact list, the two-meaning table (TWO_WAYS, which
   also holds numbers and days), the people and question lists, the part-of-speech list, then the
   same word without -s, -es, -ies, -ing, -ed, -er, -est or -ly. A capitalised word that isn't in
   any list is taken as a name (People).
   Sure or not: an answer from the part-of-speech list is marked unsure when Moby gives that word
   more than one part of speech ("sink", "fly"), unless a rule or list above settled it. Unknown
   words are Other and unsure. The editor leaves the colour picker open when it isn't sure. */
(() => {
  if (globalThis.CalmWords) return

  // Words with two common meanings: the one AAC boards use. Talk Boards' own choices are in
  // the exact list and win over these.
  const TWO_WAYS = {
    drink: 'verb', play: 'verb', brush: 'verb', hug: 'verb', kiss: 'verb', look: 'verb', watch: 'verb',
    love: 'verb', like: 'verb', need: 'verb', make: 'verb', work: 'verb', walk: 'verb', run: 'verb', dress: 'noun',
    jump: 'verb', push: 'verb', pull: 'verb', fix: 'verb', clean: 'verb', share: 'verb',
    finish: 'verb', rest: 'verb', sleep: 'verb', nap: 'noun', bath: 'noun', bathe: 'verb', cook: 'verb', bear: 'noun',
    kick: 'verb', throw: 'verb', catch: 'verb', ride: 'verb', fly: 'verb', swim: 'verb', climb: 'verb',
    tickle: 'verb', pour: 'verb', point: 'verb', touch: 'verb', smell: 'verb', taste: 'verb', feel: 'verb',
    turn: 'verb', stop: 'verb', go: 'verb', help: 'verb', open: 'verb', close: 'verb', shut: 'verb',
    move: 'verb', change: 'verb', build: 'verb', write: 'verb', draw: 'verb', paint: 'verb', color: 'verb',
    colour: 'verb', cut: 'verb', wash: 'verb', wipe: 'verb', blow: 'verb', drop: 'verb', try: 'verb',
    get: 'verb', give: 'verb', put: 'verb', take: 'verb', have: 'verb', want: 'verb', do: 'verb',
    // things more often than actions on a board
    snack: 'noun', water: 'noun', milk: 'noun', juice: 'noun', break: 'noun', toilet: 'noun',
    book: 'noun', ball: 'noun', light: 'noun', lights: 'noun', glue: 'noun', tape: 'noun', comb: 'noun',
    swing: 'noun', slide: 'noun', present: 'noun', rain: 'noun', snow: 'noun', line: 'noun', seat: 'noun',
    spray: 'noun', paper: 'noun', ice: 'noun', fire: 'noun', bus: 'noun', bell: 'noun', drum: 'noun',
    hat: 'noun', coat: 'noun', scarf: 'noun', mitten: 'noun', mittens: 'noun', boot: 'noun', shoe: 'noun',
    cup: 'noun', plate: 'noun', bed: 'noun', home: 'noun', school: 'noun', park: 'noun', time: 'noun',
    music: 'noun', song: 'noun', game: 'noun', toy: 'noun', block: 'noun', blocks: 'noun', puzzle: 'noun',
    potty: 'noun', sink: 'noun', tub: 'noun', towel: 'noun',
    // numbers and days: Talk Boards has none, so they are Things, all the same
    ...Object.fromEntries(('zero one two three four five six seven eight nine ten eleven twelve twenty hundred ' +
      'monday tuesday wednesday thursday friday saturday sunday weekend').split(' ').map((w) => [w, 'noun'])),
    // describing words lists often call something else
    all: 'describe', done: 'describe', again: 'describe', more: 'describe', some: 'describe', another: 'describe',
    big: 'describe', little: 'describe', fast: 'describe', slow: 'describe', hot: 'describe', cold: 'describe',
    good: 'describe', bad: 'describe', same: 'describe', different: 'describe', here: 'place', there: 'place',
    now: 'describe', later: 'describe', soon: 'describe', first: 'describe', next: 'describe', last: 'describe',
    // little words
    up: 'place', down: 'place', in: 'place', out: 'place', on: 'place', off: 'place', under: 'place',
    over: 'place', with: 'place', and: 'place', or: 'place', the: 'place', a: 'place', an: 'place', to: 'place',
    for: 'place', of: 'place', at: 'place', by: 'place', from: 'place', into: 'place', behind: 'place',
    // social words
    yes: 'social', please: 'social', thanks: 'social', hi: 'social', hello: 'social', bye: 'social',
    sorry: 'social', ok: 'social', okay: 'social', oops: 'social', uh: 'social', wow: 'social', yay: 'social',
    // no / not (the classroom board colours "no" white, so "no" itself is in the exact list as Other)
    not: 'negative', "don't": 'negative', dont: 'negative', "can't": 'negative', cant: 'negative',
    "won't": 'negative', wont: 'negative', "isn't": 'negative', never: 'negative', nothing: 'negative',
    nobody: 'negative', none: 'negative', "didn't": 'negative', "doesn't": 'negative',
  }

  // People nouns go in People (yellow), as Talk Boards does with teacher, mom, friend, nurse.
  const PEOPLE = new Set(('i me my mine myself you your yours he she it him her his hers its we us our they them their ' +
    'mom mum mommy mummy mother dad daddy father grandma grandpa granny nana papa grandmother grandfather ' +
    'brother sister baby babies boy girl boys girls man woman men women kid kids child children people person ' +
    'friend friends teacher teachers nurse doctor driver principal aide helper family aunt uncle cousin ' +
    'everyone everybody someone somebody anyone classmate classmates neighbor neighbour police firefighter ' +
    'dentist librarian coach chef farmer mailman baker').split(' '))
  const QUESTION = new Set(['what', 'where', 'who', 'when', 'why', 'how', 'which', 'whose', "what's", "where's", "who's", 'whats', 'wheres'])
  const NEGATIVE = new Set(['not', "don't", 'dont', "can't", 'cant', "won't", 'wont', 'never', "isn't", "didn't", "doesn't", "aren't", 'no'])
  const TITLES = new Set(['mr', 'mrs', 'ms', 'miss', 'mx', 'dr', 'sir', 'madam', 'coach', 'nurse', 'teacher', 'aunt', 'uncle', 'grandma', 'grandpa'])
  const DESCRIBE_START = new Set(['too', 'so', 'very', 'really', 'super', 'all'])
  // Social phrases a word list can't see as one: the words alone would read as Things or Describing.
  const SOCIAL = new Set(['good job', 'good night', 'goodnight', 'well done', 'high five', 'excuse me', 'i love you',
    'love you', 'see you', 'see you later', 'oh no', 'uh oh', 'bless you', "you're welcome", 'youre welcome', 'no thank you', 'no thanks',
    'good afternoon', 'good evening', 'how are you', 'nice to meet you'])
  const DETERMINER = new Set(['a', 'an', 'the', 'my', 'your', 'his', 'her', 'our', 'their', 'some', 'this', 'that', 'these', 'those', 'more', 'another', 'one', 'two', 'three'])
  const PARTICLES = new Set(['on', 'off', 'up', 'down', 'out', 'away', 'back', 'over'])
  const POLITE_END = [['please'], ['thanks'], ['thank', 'you'], ['now', 'please']]

  const norm = (text) => String(text || '').toLowerCase().replace(/[’‘`]/g, "'").replace(/[^a-z0-9' ]+/g, ' ').replace(/\s+/g, ' ').trim()

  let exact = {}
  let pos = new Map()
  function load(data) {
    exact = data.exact || {}
    pos = new Map()
    for (const [cat, words] of Object.entries(data.pos || {})) for (const w of words.split(' ')) if (w) pos.set(w, cat)
    multi = new Set((data.multi || '').split(' ').filter(Boolean))
  }

  let multi = new Set()
  // [category, sure] for one word, or null.
  function lookup(w, mine) {
    if (mine[w]) return [mine[w], true]
    if (exact[w]) return [exact[w], true]
    if (Object.hasOwn(TWO_WAYS, w)) return [TWO_WAYS[w], true]
    if (PEOPLE.has(w)) return ['pronoun', true]
    if (QUESTION.has(w)) return ['question', true]
    if (pos.has(w)) return [pos.get(w), !multi.has(w)]
    const tries = []
    if (w.endsWith('ies')) tries.push([w.slice(0, -3) + 'y'])
    if (w.endsWith('es')) tries.push([w.slice(0, -2)])
    if (w.endsWith('s') && !w.endsWith('ss')) tries.push([w.slice(0, -1)])
    if (w.endsWith('ing')) { const b = w.slice(0, -3); tries.push([b, 'verb'], [b + 'e', 'verb'], [b.slice(0, -1), 'verb']) }
    if (w.endsWith('ed')) { const b = w.slice(0, -2); tries.push([b], [b + 'e'], [b.slice(0, -1)], [w.slice(0, -1)]) }
    if (w.endsWith('ied')) tries.push([w.slice(0, -3) + 'y'])
    if (w.endsWith('er') || w.endsWith('est')) { const b = w.replace(/(er|est)$/, ''); tries.push([b, 'describe'], [b + 'e', 'describe'], [b.slice(0, -1), 'describe']) }
    if (w.endsWith('ier') || w.endsWith('iest')) tries.push([w.replace(/(ier|iest)$/, 'y'), 'describe'])
    if (w.endsWith('ly')) tries.push([w.slice(0, -2), 'describe'])
    for (const [base, as] of tries) {
      if (base.length < 2) continue
      const sure = mine[base] || exact[base] || Object.hasOwn(TWO_WAYS, base) || PEOPLE.has(base) || !multi.has(base)
      const c = mine[base] || exact[base] || (Object.hasOwn(TWO_WAYS, base) ? TWO_WAYS[base] : null) || (PEOPLE.has(base) ? 'pronoun' : null) || pos.get(base)
      // "-ing" of a verb is still an action; "-er"/"-est"/"-ly" only count when the base describes
      if (c && (!as || as === c)) return [c, !!sure]
    }
    return null
  }

  // [category, sure] for a list of words, or null.
  function phrase(words, mine, depth = 0) {
    const t = words.join(' ')
    if (!t) return null
    if (mine[t]) return [mine[t], true]
    if (exact[t]) return [exact[t], true]
    if (SOCIAL.has(t)) return ['social', true]
    if (words.length === 1) return lookup(words[0], mine)
    const [first, second] = words
    if ((first === 'i' && ['feel', 'am', 'felt'].includes(second)) || first === "i'm" || first === 'im' || first === 'feel' || first === 'feeling') return ['describe', true]
    if (words.length <= 5 && words.includes('or')) return ['question', true] // a choice: "yes or no", "this or that"
    if (words.some((w) => NEGATIVE.has(w))) return ['negative', true]
    // A title and a name: "Mr Lee", "Mrs Lopez", "Miss Kay". ("miss you" isn't one.)
    if (TITLES.has(first) && !PEOPLE.has(second) && (['mr', 'mrs', 'ms', 'miss', 'mx', 'dr'].includes(first) || (words.length === 2 && !lookup(second, mine)?.[1]))) return ['pronoun', true]
    let rest = null
    if (first === 'i' && ['need', 'want', 'like', 'have', 'got', 'see'].includes(second)) rest = words.slice(2)
    else if (first === 'i' && second === 'would' && words[2] === 'like') rest = words.slice(3)
    else if (first === 'can' && second === 'i' && ['have', 'get'].includes(words[2])) rest = words.slice(3)
    else if (['need', 'want'].includes(first) && words.length > 1) rest = words.slice(1)
    if (rest && depth < 3) return rest[0] === 'to' ? ['verb', true] : phrase(rest, mine, depth + 1)
    if (first === 'to') return ['verb', true]
    if (first === 'i' && lookup(second, mine)?.[0] === 'verb') return ['verb', true] // "I miss you", "I go"
    if (QUESTION.has(first)) return ['question', true]
    if (DESCRIBE_START.has(first)) return ['describe', true]
    if (DETERMINER.has(first) && depth < 3) {
      const r = phrase(words.slice(1), mine, depth + 1)
      if (r) return r
    }
    const lead = lookup(first, mine)
    if (lead?.[0] === 'verb') return lead
    const last = words[words.length - 1]
    if (PARTICLES.has(last) && words.length > 1) return ['verb', true]
    const head = lookup(last, mine)
    // After a describing word the last word names a thing: "little bear", "big swing".
    if (head?.[0] === 'verb' && lead?.[0] === 'describe') return ['noun', head[1]]
    return head
  }

  /** {category, sure, yours?} for the words on a button. `mine` is the teacher's remembered choices. */
  function guess(text, mine = {}) {
    let words = norm(text).split(' ').filter(Boolean)
    if (!words.length) return { category: 'neutral', sure: false }
    const whole = words.join(' ')
    if (mine[whole]) return { category: mine[whole], sure: true, yours: true }
    if (exact[whole]) return { category: exact[whole], sure: true }
    if (SOCIAL.has(whole)) return { category: 'social', sure: true } // before "thank you" is dropped
    for (const end of POLITE_END) {
      const n = end.length
      if (words.length > n && words.slice(-n).join(' ') === end.join(' ')) { words = words.slice(0, -n); break }
    }
    const r = phrase(words, mine)
    // A capitalised word nobody knows is most likely a name.
    if (!r && /^[A-Z][a-z'-]+$/.test(String(text).trim())) return { category: 'pronoun', sure: false }
    if (!r) return { category: 'neutral', sure: false }
    return { category: r[0], sure: r[1] }
  }

  globalThis.CalmWords = { load, guess, norm }
})()
