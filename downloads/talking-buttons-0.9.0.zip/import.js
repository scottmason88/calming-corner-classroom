/* Opens a calm-buttons file into one activity. The overlay on the activity's tab sees the
   change through chrome.storage and redraws. */
const C = globalThis.CalmCommon
const params = new URLSearchParams(location.search)
const key = params.get('key')
const $ = (x) => document.getElementById(x)
$('title').textContent = params.get('title') || 'this activity'
let incoming = null
const slide = params.get('slide') || ''
// A Slides deck shows only the sets tied to slides unless "Different buttons on each slide" is off.
const perSlideDeck = () => key.startsWith('slides:') && (existingRecord ? existingRecord.perSlide !== false : true)
let existingRecord = null
chrome.storage.local.get(key).then((r) => { existingRecord = r[key] || null })

$('file').addEventListener('change', async (e) => {
  $('error').textContent = ''
  $('ready').hidden = true
  const file = e.target.files[0]
  if (!file) return
  try {
    incoming = C.fromFile(JSON.parse(await file.text()))
  } catch (err) {
    incoming = null
    $('error').textContent = err instanceof SyntaxError ? 'That file can’t be read. Is it a talking-buttons file?' : err.message
    return
  }
  const n = incoming.sets.reduce((t, s) => t + s.buttons.length, 0)
  const loose = incoming.sets.some((s) => !s.slide) && perSlideDeck()
  $('add').disabled = loose && !slide
  $('where').textContent = !loose ? ''
    : slide ? 'If you add them, the sets that aren’t matched to slides go on the slide that’s open now.'
      : 'To add these, open the slide you want them on first, then open the file again.'
  const slides = incoming.sets.filter((s) => s.slide).length
  $('summary').textContent = `“${incoming.title || file.name}”: ${n} button${n === 1 ? '' : 's'} in ${incoming.sets.length} set${incoming.sets.length === 1 ? '' : 's'}`
    + (slides ? `, ${slides} matched to slides` : '') + (incoming.core ? ', with core words.' : '.')
  $('ready').hidden = false
})

async function apply(replace) {
  const existing = (await chrome.storage.local.get(key))[key]
  const record = existing ? { ...existing } : C.emptyRecord(params.get('title') || incoming.title, key.startsWith('slides:'))
  if (replace) record.sets = incoming.sets
  else {
    // Adding: sets for the same slide merge; everything else is appended. On a deck with buttons
    // per slide, sets without a slide go on the open slide, so none end up where they can't be seen.
    record.sets = [...(record.sets || [])]
    for (const s of incoming.sets) {
      s.buttons = s.buttons.map((b) => ({ ...b, id: C.newId() })) // the same file opened twice must not share ids
      if (!s.slide && record.perSlide && key.startsWith('slides:')) {
        if (!slide) continue
        s.slide = slide
      }
      const same = s.slide && record.sets.find((x) => x.slide === s.slide)
      if (same) same.buttons = [...same.buttons, ...s.buttons]
      else record.sets.push(s)
    }
  }
  record.core = incoming.core || (!replace && !!record.core)
  if (typeof incoming.sentence === 'boolean') record.sentence = incoming.sentence
  else if (replace) delete record.sentence
  if (incoming.sets.some((s) => s.slide)) record.perSlide = true
  else if (replace && key.startsWith('slides:')) record.perSlide = false
  record.setIndex = 0
  if (!record.title) record.title = incoming.title
  record.updated = Date.now()
  await chrome.storage.local.set({ [key]: record })
  finish()
}

async function finish() {
  await chrome.runtime.sendMessage({ type: 'focusTab', tab: params.get('tab') }).catch(() => {})
  const me = await chrome.tabs.getCurrent()
  if (me) chrome.tabs.remove(me.id)
  else window.close()
}

$('replace').addEventListener('click', () => apply(true))
$('add').addEventListener('click', () => apply(false))
$('cancel').addEventListener('click', finish)
