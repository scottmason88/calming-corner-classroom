/* Service worker. Hands the page overlay the files bundled with the extension
   (so nothing needs to be web-accessible), takes screenshots for "Grab from the page",
   and opens the recording and import pages. It makes no network requests. */

/* global importScripts, CalmWords, CalmCommon */
importScripts('common.js', 'words.js')

const asset = (path) => chrome.runtime.getURL('assets/' + path)

// Automatic button colours: the rules are in words.js, the word lists in words.json, and the
// teacher's own choices in chrome.storage.local under "wordColours" (they win).
let wordsReady = null
const words = () => (wordsReady ||= fetch(chrome.runtime.getURL('words.json')).then((r) => r.json()).then((d) => CalmWords.load(d))
  .catch((e) => { wordsReady = null; throw e })) // try again next time rather than keep the failure
const myColours = async () => (await chrome.storage.local.get('wordColours')).wordColours || {}
// Remembered colours are read, changed and written back; one change at a time, so two quick
// saves can't overwrite each other.
let colourWrites = Promise.resolve()
function changeColours(fn) {
  const next = colourWrites.then(async () => {
    const mine = await myColours()
    const out = fn(mine)
    await chrome.storage.local.set({ wordColours: mine })
    return out
  })
  colourWrites = next.catch(() => {})
  return next
}

function toBase64(buf) {
  const bytes = new Uint8Array(buf)
  let s = ''
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000))
  return btoa(s)
}
async function readText(path) {
  const r = await fetch(asset(path))
  if (!r.ok) throw new Error('missing ' + path)
  return r.text()
}
async function svgDataUrl(path) {
  return 'data:image/svg+xml;base64,' + toBase64(new TextEncoder().encode(await readText(path)))
}

let clipIndex = null
async function clips() {
  if (!clipIndex) clipIndex = JSON.parse(await readText('clips/index.json'))
  return clipIndex
}

let libraryIndex = null
async function library() {
  if (!libraryIndex) libraryIndex = JSON.parse(await readText('library/index.json'))
  return libraryIndex
}
const libraryPath = (id) => id.startsWith('m:') ? `library/mulberry/${id.slice(2)}.svg` : `library/openmoji/${id.slice(2)}.svg`

async function search(q) {
  const words = String(q || '').toLowerCase().split(/[^a-z0-9]+/).filter(Boolean)
  if (!words.length) return []
  const scored = []
  for (const [id, label, extra] of await library()) {
    const l = label.toLowerCase()
    let score = 0
    for (const w of words) {
      if (l === w) score += 100
      else if (new RegExp(`\\b${w}`).test(l)) score += 20
      else if (l.includes(w)) score += 5
      else if (extra.includes(w)) score += 2
      else { score = 0; break }
    }
    if (score) scored.push([score - l.length / 100 + (id.startsWith('m:') ? 0.5 : 0), id, label])
  }
  scored.sort((a, b) => b[0] - a[0])
  return Promise.all(scored.slice(0, 40).map(async ([, id, label]) => ({ id, label, picture: await svgDataUrl(libraryPath(id)) })))
}

const handlers = {
  async clipIndex() { return clips() },
  async clip({ slug }) {
    if (!(await clips()).includes(slug)) return null
    const r = await fetch(asset(`clips/${slug}.mp3`))
    return toBase64(await r.arrayBuffer())
  },
  async core() {
    const out = {}
    for (const slug of ['i', 'want', 'put', 'on', 'off', 'more', 'finished', 'help', 'stop', 'go', 'no']) out[slug] = await svgDataUrl(`core/${slug}.svg`)
    return out
  },
  async search({ q }) { return search(q) },
  async colour({ text }) {
    await words()
    return CalmWords.guess(text, await myColours())
  },
  async rememberColour({ text, category }) {
    const key = CalmWords.norm(text)
    if (!key || !CalmCommon.CATEGORY_KEYS.has(category)) return false
    return changeColours((mine) => { mine[key] = category; return true })
  },
  async forgetColour({ text }) {
    const key = CalmWords.norm(text)
    return changeColours((mine) => delete mine[key])
  },
  async forgetAllColours() {
    return changeColours((mine) => { const n = Object.keys(mine).length; for (const k of Object.keys(mine)) delete mine[k]; return n })
  },
  async capture(_msg, sender) {
    // Needs the activeTab grant (clicking the toolbar button) on most pages.
    return chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: 'png' })
  },
  async openPage({ page, params }, sender) {
    const q = new URLSearchParams({ ...params, tab: String(sender.tab?.id ?? params.tab ?? '') })
    await chrome.tabs.create({ url: chrome.runtime.getURL(`${page}.html?${q}`), index: (sender.tab?.index ?? 0) + 1 })
    return true
  },
  async focusTab({ tab }) {
    if (tab) await chrome.tabs.update(Number(tab), { active: true })
    return true
  },
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  const fn = handlers[msg?.type]
  if (!fn) return false
  fn(msg, sender).then((value) => reply({ ok: true, value }), (e) => reply({ ok: false, error: String(e?.message || e) }))
  return true
})
