/* Runs at document_start on Google Slides, before any of the page's own scripts. Google Slides
   listens for keys at the window and document in the capture phase, which runs before an event
   reaches the overlay's buttons, so stopping keys in the overlay itself would be too late: an
   arrow key meant to nudge a button could also move the slide.
   This listener is registered first, so it runs first. When a key is aimed at the overlay (the
   event's target is its host element), it hands the key to the overlay and stops the page from
   seeing it. Keys anywhere else are untouched. Typing still works: only the page's key listeners
   are skipped, not the browser's own handling of the key. */
;(() => {
  if (window.__calmGuard) return
  window.__calmGuard = true
  for (const type of ['keydown', 'keyup', 'keypress']) {
    window.addEventListener(type, (e) => {
      if (e.target?.localName !== 'calm-buttons-overlay') return
      e.stopImmediatePropagation()
      window.__calmButtons?.key?.(e)
    }, true)
  }
})()
