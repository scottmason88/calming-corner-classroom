/* Shared by the page overlay, the popup and the extension pages.
   Loaded as a classic script, so everything hangs off one global. */
(() => {
  if (globalThis.CalmCommon) return

  // The tests load a copy of the extension with this set to true (see tests/global-setup.mjs).
  // It only opens the overlay's shadow root so Playwright can reach inside it.
  const TEST_BUILD = false

  // The same colour key as the board maker and the classroom board (Fitzgerald-style).
  const CATEGORIES = [
    { key: 'pronoun', name: 'People', color: '#f8efae' },
    { key: 'verb', name: 'Actions', color: '#d8eed3' },
    { key: 'describe', name: 'Describing', color: '#cde4f6' },
    { key: 'noun', name: 'Things', color: '#fde0c2' },
    { key: 'place', name: 'Little words', color: '#e6def1' },
    { key: 'social', name: 'Social', color: '#f9d3e3' },
    { key: 'question', name: 'Questions', color: '#d9c8ef' },
    { key: 'negative', name: 'No / not', color: '#f6c6c3' },
    { key: 'neutral', name: 'Other', color: '#ffffff' },
  ]
  const CATEGORY_KEYS = new Set(CATEGORIES.map((c) => c.key))
  const categoryColor = (key) => (CATEGORIES.find((c) => c.key === key) || CATEGORIES[CATEGORIES.length - 1]).color

  // The core-word strip: always these words, always this order.
  // [slug, label, category]; pictures are in assets/core/<slug>.svg.
  const CORE = [
    ['i', 'I', 'pronoun'], ['want', 'want', 'verb'], ['put', 'put', 'verb'], ['on', 'on', 'place'],
    ['off', 'off', 'place'], ['more', 'more', 'describe'], ['finished', 'finished', 'describe'],
    ['help', 'help', 'verb'], ['stop', 'stop', 'verb'], ['go', 'go', 'verb'], ['no', 'no', 'neutral'],
  ]

  // Matches slugify() in classroom-board/render_voice.py, so "Put on." finds put-on.mp3.
  const slugify = (text) => String(text || '').toLowerCase().replace(/['’]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')

  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v))
  const num = (v, d) => (typeof v === 'number' && Number.isFinite(v) ? v : d)
  const newId = () => 'b' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7)

  /* Google Slides: presentation id from the path, current slide from ?slide= or #slide=.
     Edit mode:     /presentation/d/<id>/edit#slide=id.p3
     Present mode:  /presentation/d/<id>/present?slide=id.p3  (and /edit?...#slide=... variants)
     Published:     /presentation/d/e/<pubid>/pub?start=false&slide=id.p3  */
  function slidesInfo(href) {
    let u
    try { u = new URL(href) } catch { return null }
    if (u.hostname !== 'docs.google.com') return null
    const m = u.pathname.match(/^\/presentation\/(?:u\/\d+\/)?d\/(e\/)?([A-Za-z0-9_-]+)/)
    if (!m) return null
    const pick = (s) => {
      const v = new URLSearchParams(s.replace(/^[#?]/, '')).get('slide')
      return v ? v.replace(/^id\./, '') : null
    }
    return { id: (m[1] ? 'e/' : '') + m[2], slide: pick(u.hash) || pick(u.search) }
  }

  function activityKey(href) {
    const s = slidesInfo(href)
    if (s) return 'slides:' + s.id
    const u = new URL(href)
    return 'url:' + u.origin + u.pathname + u.search
  }

  /* The shared button-set file, also read and written by the book maker:
     {"format":"calm-buttons","version":1,"title","core","sets":[{"name","slide"?,"buttons":[...]}]} */
  function toFile(record) {
    return {
      format: 'calm-buttons',
      version: 1,
      title: record.title || '',
      core: !!record.core,
      // The book maker's sentence-bar flag: not used here, but kept so it survives a round trip.
      ...(typeof record.sentence === 'boolean' ? { sentence: record.sentence } : {}),
      sets: (record.sets || []).filter((s) => s.buttons.length).map((s) => {
        const out = { name: s.name || '' }
        if (s.slide) out.slide = s.slide
        out.buttons = s.buttons.map((b) => ({
          id: b.id, label: b.label, say: b.say, category: b.category,
          picture: b.picture || null, clip: b.clip || null,
          x: b.x, y: b.y, w: b.w, h: b.h,
        }))
        return out
      }),
    }
  }

  const B64 = /^[A-Za-z0-9+/=\s]+$/
  // A clip is bare base64 (MP3), or a data: URL when it's a recording in another format
  // (the book maker and the recording page write data:audio/webm;codecs=opus;base64,…).
  // Data URLs keep their type so the audio decodes as what it is.
  function cleanClip(clip) {
    if (typeof clip !== 'string' || !clip || clip.length > 12e6) return null
    const m = clip.match(/^data:(audio\/[a-z0-9.+-]+(?:;[a-z0-9.+-]+=[a-z0-9.+-]+)*);base64,/i)
    if (!m && clip.startsWith('data:')) return null // not audio
    const body = m ? clip.slice(m[0].length) : clip
    return body && B64.test(body.slice(0, 4096)) ? clip : null
  }
  const clipBase64 = (clip) => clip.replace(/^data:[^,]*,/, '')
  function cleanButton(b, i) {
    if (!b || typeof b !== 'object') return null
    const label = String(b.label ?? '').slice(0, 80)
    const say = String(b.say ?? label).slice(0, 300)
    const placed = ['x', 'y', 'w', 'h'].every((k) => typeof b[k] === 'number' && Number.isFinite(b[k]))
    // Files without positions (the book maker can leave them out) get a tidy row along the top.
    const w = placed ? clamp(b.w, 0.03, 1) : 0.11
    const h = placed ? clamp(b.h, 0.03, 1) : 0.19
    const x = placed ? clamp(b.x, 0, 1 - w) : clamp(0.02 + (i % 8) * 0.12, 0, 1 - w)
    const y = placed ? clamp(b.y, 0, 1 - h) : clamp(0.04 + Math.floor(i / 8) * 0.22, 0, 1 - h)
    return {
      id: typeof b.id === 'string' && b.id ? b.id.slice(0, 64) : newId(),
      label, say,
      category: CATEGORY_KEYS.has(b.category) ? b.category : 'neutral',
      picture: typeof b.picture === 'string' && /^data:image\/(png|jpe?g|gif|webp|svg\+xml)[;,]/.test(b.picture) ? b.picture : null,
      clip: cleanClip(b.clip),
      x, y, w, h,
    }
  }

  // Returns {title, core, sets} or throws a message a teacher can read.
  function fromFile(data) {
    if (!data || data.format !== 'calm-buttons') throw new Error('This is not a calm-buttons file.')
    if (typeof data.version !== 'number' || data.version > 1) throw new Error('This file was made by a newer version. Update the extension and try again.')
    if (!Array.isArray(data.sets)) throw new Error('This file has no button sets.')
    const sets = data.sets.slice(0, 500).map((s, n) => {
      const set = { name: String(s?.name ?? `Set ${n + 1}`).slice(0, 80), buttons: [] }
      if (typeof s?.slide === 'string' && s.slide) set.slide = s.slide.replace(/^id\./, '').slice(0, 128)
      set.buttons = (Array.isArray(s?.buttons) ? s.buttons : []).slice(0, 200).map(cleanButton).filter(Boolean)
      return set
    })
    const out = { title: String(data.title ?? '').slice(0, 200), core: !!data.core, sets }
    if (typeof data.sentence === 'boolean') out.sentence = data.sentence
    return out
  }

  function emptyRecord(title, slides) {
    return { title: title || '', core: false, coreEdge: 'bottom', perSlide: !!slides, setIndex: 0, hidden: false, sets: [] }
  }

  globalThis.CalmCommon = { TEST_BUILD, cleanClip, clipBase64, CATEGORIES, CATEGORY_KEYS, categoryColor, CORE, slugify, clamp, num, newId, slidesInfo, activityKey, toFile, fromFile, cleanButton, emptyRecord }
})()
