/* The toolbar popup. It talks to the overlay in the current tab, and puts the overlay
   there first if the page is not a Google Slides one (the activeTab permission allows
   this only because the teacher clicked the toolbar button). */
const params = new URLSearchParams(location.search)
const $ = (id) => document.getElementById(id)
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
let tab = null
let state = null

async function ask(msg) {
  try { return await chrome.tabs.sendMessage(tab.id, msg) } catch { return undefined }
}

async function connect() {
  // ?tab= lets the tests open this page in a normal tab and point it at another tab.
  if (params.get('tab')) tab = { id: Number(params.get('tab')) }
  else [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (!tab) return null
  let s = await ask({ type: 'state' })
  if (s) return s
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['guard.js', 'common.js', 'content.js'] })
  } catch {
    return null
  }
  for (let i = 0; i < 30 && !s; i++) { s = await ask({ type: 'state' }); if (!s) await sleep(100) }
  return s || null
}

function show(s) {
  state = s
  $('title').textContent = s.title || 'Untitled activity'
  const here = s.isSlides && s.perSlide && s.slideId ? 'on this slide' : `in ${s.setName}`
  $('where').textContent = `${s.buttonCount} button${s.buttonCount === 1 ? '' : 's'} ${here}` + (s.totalButtons > s.buttonCount ? ` · ${s.totalButtons} in all` : '')
  $('edit').setAttribute('aria-pressed', String(s.mode === 'edit' && !s.hidden))
  $('play').setAttribute('aria-pressed', String(s.mode === 'play' && !s.hidden))
  $('coreSize').value = s.core ? s.coreSize : 'hide'
  $('edge').value = s.coreEdge
  $('edge').disabled = !s.core
  $('perSlideRow').hidden = !s.isSlides
  $('perSlide').checked = s.perSlide
  $('show').checked = !s.hidden
}

async function update(msg) {
  const s = await ask(msg)
  if (s) show(s)
}

$('edit').addEventListener('click', () => update({ type: 'setMode', mode: 'edit' }))
$('play').addEventListener('click', () => update({ type: 'setMode', mode: 'play' }))
$('coreSize').addEventListener('change', (e) => update(e.target.value === 'hide' ? { type: 'setOption', core: false } : { type: 'setOption', core: true, coreSize: e.target.value }))
// The size new buttons start at is a setting for every activity, so it lives with the extension.
chrome.storage.local.get('prefs').then(({ prefs }) => { $('defaultSize').value = prefs?.defaultSize || 'large' })
$('defaultSize').addEventListener('change', async (e) => {
  const { prefs } = await chrome.storage.local.get('prefs')
  await chrome.storage.local.set({ prefs: { ...(prefs || {}), defaultSize: e.target.value } })
})
$('edge').addEventListener('change', (e) => update({ type: 'setOption', coreEdge: e.target.value }))
$('perSlide').addEventListener('change', (e) => update({ type: 'setOption', perSlide: e.target.checked }))
$('show').addEventListener('change', (e) => update({ type: 'setOption', hidden: !e.target.checked }))
$('grab').addEventListener('click', async () => {
  await ask({ type: 'grab' })
  if (!params.get('tab')) window.close()
})
$('export').addEventListener('click', async () => {
  const file = await ask({ type: 'export' })
  if (!file) return
  const name = (file.title || 'activity').replace(/[\\/:*?"<>|]+/g, ' ').trim().slice(0, 60) || 'activity'
  const a = document.createElement('a')
  a.href = URL.createObjectURL(new Blob([JSON.stringify(file, null, 1)], { type: 'application/json' }))
  a.download = `${name} - talking buttons.json`
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(a.href), 10000)
})
$('import').addEventListener('click', async () => {
  // A file chooser inside the popup can close the popup before the file arrives, so use a tab.
  const q = new URLSearchParams({ key: state.key, tab: String(tab.id), title: state.title, slide: state.isSlides && state.perSlide ? state.slideId || '' : '' })
  await chrome.tabs.create({ url: chrome.runtime.getURL(`import.html?${q}`) })
  if (!params.get('tab')) window.close()
})

// Colours the teacher picked by hand are remembered for those words, for every activity.
// "Forget my colour choices" clears them (a second tap confirms).
async function showForget() {
  const { wordColours } = await chrome.storage.local.get('wordColours')
  const n = Object.keys(wordColours || {}).length
  $('forget').hidden = !n
  $('forget').textContent = `Forget my ${n} colour choice${n === 1 ? '' : 's'}`
  delete $('forget').dataset.armed
}
$('forget').addEventListener('click', async () => {
  const b = $('forget')
  if (!b.dataset.armed) {
    b.dataset.armed = '1'
    b.textContent = 'Tap again to forget them'
    setTimeout(() => { if (b.dataset.armed) showForget() }, 5000)
    return
  }
  const r = await chrome.runtime.sendMessage({ type: 'forgetAllColours' })
  b.hidden = true
  $('forgotten').hidden = false
  $('forgotten').textContent = r?.ok ? 'Forgotten. Colours are chosen from the words again.' : 'Could not forget them.'
})
showForget()

// The overlay speaks only with voices that run on this computer; say so when there are none.
async function checkVoices() {
  if (!window.speechSynthesis) { $('novoice').hidden = false; return }
  let voices = speechSynthesis.getVoices()
  if (!voices.length) {
    await new Promise((r) => { speechSynthesis.addEventListener('voiceschanged', r, { once: true }); setTimeout(r, 1500) })
    voices = speechSynthesis.getVoices()
  }
  $('novoice').hidden = voices.some((v) => v.localService)
}

connect().then((s) => {
  if (!s) { $('unavailable').hidden = false; return }
  $('main').hidden = false
  show(s)
  checkVoices()
})
