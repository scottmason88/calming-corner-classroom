/* The page overlay: talking picture buttons on top of an activity.

   Everything lives in one shadow root on a position:fixed layer with pointer-events:none,
   so the activity underneath keeps working everywhere except on the buttons themselves.
   The activity's own page is never changed. */
(() => {
  if (window.__calmButtons) return
  const C = globalThis.CalmCommon
  // The content script matches all of docs.google.com/presentation/, which includes the Slides
  // home list; only decks (/presentation/d/…) get the overlay.
  if (location.hostname === 'docs.google.com' && location.pathname.startsWith('/presentation/') && !C.slidesInfo(location.href)) return
  const api = (window.__calmButtons = {})

  /* ---------- messaging ---------- */
  function send(type, extra = {}) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type, ...extra }, (r) => {
          void chrome.runtime.lastError
          resolve(r || { ok: false, error: 'no answer' })
        })
      } catch (e) {
        resolve({ ok: false, error: String(e) }) // the extension was reloaded; this page needs a refresh
      }
    })
  }
  const value = async (type, extra) => (await send(type, extra)).value ?? null

  /* ---------- state ---------- */
  const isSlides = !!C.slidesInfo(location.href)
  const key = C.activityKey(location.href)
  const pageTitle = () => document.title.replace(/ - Google (Slides|Präsentationen|Presentaciones)$/, '').trim()
  let slideId = null
  let record = C.emptyRecord(pageTitle(), isSlides)
  let mode = 'play'
  let clipList = new Set()
  let corePics = {}
  let busy = 0 // > 0 while dragging; storage updates wait until it ends
  let pendingRecord = null
  let editor = null // { id, draft, isNew }
  let toolbarOpen = true
  // What the tests check (what was last spoken, where the layer is). Kept in memory and only
  // reported to the extension's own pages through runtime messaging, never written into the page.
  const debug = { lastSpoke: '', spokeCount: 0, mountedIn: '' }

  const usingSlides = () => isSlides && record.perSlide && !!slideId
  const manualSets = () => record.sets.filter((s) => !s.slide)
  function currentSet(create = false) {
    if (usingSlides()) {
      let s = record.sets.find((x) => x.slide === slideId)
      if (!s && create) record.sets.push((s = { name: `Slide ${slideId}`, slide: slideId, buttons: [] }))
      return s || null
    }
    const m = manualSets()
    if (!m.length) {
      if (!create) return null
      const s = { name: 'Set 1', buttons: [] }
      record.sets.push(s)
      record.setIndex = 0
      return s
    }
    record.setIndex = C.clamp(record.setIndex | 0, 0, m.length - 1)
    return m[record.setIndex]
  }
  const buttons = () => currentSet()?.buttons || []
  const findButton = (id) => buttons().find((b) => b.id === id)

  async function save() {
    record.updated = Date.now()
    try { await chrome.storage.local.set({ [key]: record }) } catch { toast('Could not save. Refresh the page and try again.') }
  }
  function adopt(next) {
    record = { ...C.emptyRecord(pageTitle(), isSlides), ...next }
    if (!Array.isArray(record.sets)) record.sets = []
    if (editor) {
      // A recording made in the recording tab arrives here while the editor is open.
      const fresh = record.sets.flatMap((s) => s.buttons).find((b) => b.id === editor.id)
      if (fresh) editor.draft.clip = fresh.clip
      renderEditor()
    }
    render()
  }
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes[key]) return
      const next = changes[key].newValue
      if (next && next.updated === record.updated) return // our own write
      const rec = next || C.emptyRecord(pageTitle(), isSlides)
      if (busy) pendingRecord = rec
      else adopt(rec)
    })
  } catch { /* extension reloaded */ }

  /* ---------- audio ---------- */
  let ctx = null
  const buffers = new Map() // key -> AudioBuffer | Promise
  let playing = null
  function audio() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext
      if (AC) ctx = new AC()
    }
    return ctx
  }
  function bytes(b64) {
    const s = atob(C.clipBase64(b64))
    const out = new Uint8Array(s.length)
    for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i)
    return out.buffer
  }
  // Voice order, the same as the book maker: the Calming Corner clip whose name matches what the
  // button says, then the teacher's recording, then the computer's voice.
  const calmSlug = (b) => { const slug = C.slugify(b.say || b.label); return slug && clipList.has(slug) ? slug : null }
  function voiceFor(b) {
    const slug = calmSlug(b)
    if (slug) return { kind: 'clip', key: `clip:${slug}`, b64: () => value('clip', { slug }), name: slug }
    if (b.clip) return { kind: 'recording', key: `rec:${b.id}:${b.clip.length}:${b.clip.slice(-16)}`, b64: () => b.clip, name: b.id }
    return { kind: 'speech', name: b.say || b.label }
  }
  function decoded(v) {
    if (!buffers.has(v.key)) {
      const p = (async () => {
        const b64 = await v.b64()
        if (!b64 || !audio()) throw new Error('no audio')
        return ctx.decodeAudioData(bytes(b64))
      })()
      buffers.set(v.key, p)
      p.then((buf) => buffers.set(v.key, buf), () => buffers.delete(v.key))
    }
    return buffers.get(v.key)
  }
  function stopAll() {
    try { playing?.stop() } catch { /* already stopped */ }
    playing = null
    try { speechSynthesis.cancel() } catch { /* no speech */ }
  }
  // Only voices that run on this computer. Network voices (Chrome's "Google US English" and
  // friends) send the text to a server, which would break the promise that nothing leaves the
  // computer, so they are never used. The popup warns when there's no local voice.
  async function localVoice() {
    let all = speechSynthesis.getVoices()
    if (!all.length) {
      // Chrome fills the list in shortly after the page loads.
      await new Promise((r) => { speechSynthesis.addEventListener('voiceschanged', r, { once: true }); setTimeout(r, 1000) })
      all = speechSynthesis.getVoices()
    }
    const local = all.filter((v) => v.localService)
    const en = local.filter((v) => /^en(-|_|$)/i.test(v.lang))
    return en.find((v) => v.default) || en[0] || local.find((v) => v.default) || local[0] || null
  }
  async function speakText(text) {
    if (!text || !window.speechSynthesis) return
    const voice = await localVoice()
    if (!voice) { debug.lastSpoke = 'no-voice:' + text; return }
    const u = new SpeechSynthesisUtterance(text)
    u.rate = 0.9
    u.voice = voice
    u.lang = voice.lang
    speechSynthesis.speak(u)
    debug.lastSpoke = 'speech:' + text
  }
  async function speak(b) {
    stopAll()
    debug.spokeCount++
    const v = voiceFor(b)
    const text = b.say || b.label
    if (v.kind !== 'speech' && audio()) {
      if (ctx.state === 'suspended') ctx.resume()
      try {
        const buf = await decoded(v)
        const src = ctx.createBufferSource()
        src.buffer = buf
        src.connect(ctx.destination)
        src.start()
        playing = src
        debug.lastSpoke = `${v.kind}:${v.name}`
        return
      } catch { /* fall through to the computer voice */ }
    }
    speakText(text)
  }
  function preload() {
    for (const b of buttons()) { const v = voiceFor(b); if (v.kind !== 'speech') decoded(v).catch(() => {}) }
    if (record.core) for (const [slug] of C.CORE) if (clipList.has(slug)) decoded({ key: `clip:${slug}`, b64: () => value('clip', { slug }) }).catch(() => {})
  }

  /* ---------- presses: act on the first touch, ignore the extra contacts a board reports ---------- */
  let lastAny = -Infinity
  function onPress(el, fn) {
    let last = -Infinity
    el.addEventListener('pointerdown', (e) => {
      if (e.button > 0) return
      const now = performance.now()
      if (now - last < 350 || now - lastAny < 120) return
      last = lastAny = now
      flash(el)
      if (navigator.userActivation && !navigator.userActivation.hasBeenActive) {
        // Nobody has touched this page yet. A finger going down doesn't count as a user gesture
        // (lifting it does), and sound is only allowed after one, so speak when the finger lifts.
        el.addEventListener('pointerup', () => { unlockAudio(); fn(e) }, { once: true })
        return
      }
      fn(e)
    })
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); flash(el); fn(e) }
    })
  }
  function unlockAudio() {
    if (ctx && ctx.state !== 'running') ctx.resume().catch(() => {})
  }
  function flash(el) {
    el.classList.add('pressed')
    clearTimeout(el._t)
    el._t = setTimeout(() => el.classList.remove('pressed'), 240)
  }

  /* ---------- DOM ---------- */
  const host = document.createElement('calm-buttons-overlay')
  host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;display:block;'
  const root = host.attachShadow({ mode: C.TEST_BUILD ? 'open' : 'closed' })
  root.innerHTML = `<style>${CSS()}</style>
    <div class="layer">
      <div class="buttons"></div>
      <div class="strip" role="toolbar" aria-label="Core words"></div>
      <div class="dock">
        <div class="toolbar" role="toolbar" aria-label="Talking buttons"></div>
        <button class="handle" type="button" aria-label="Talking buttons"></button>
        <div class="tip"></div>
      </div>
      <div class="crop" hidden></div>
      <div class="dialog-wrap" hidden></div>
      <div class="toast" role="status" hidden></div>
    </div>`
  const $ = (s) => root.querySelector(s)
  const layer = $('.layer')
  const elButtons = $('.buttons')
  const elStrip = $('.strip')
  const elToolbar = $('.toolbar')
  const elHandle = $('.handle')
  const elTip = $('.tip')
  const elCrop = $('.crop')
  const elDialog = $('.dialog-wrap')
  const elToast = $('.toast')

  // The layer only receives events that land on our own buttons and panels. Stop them here so the
  // activity never sees them (a tap on a button must not also advance the slide while presenting).
  for (const t of ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'dblclick', 'touchstart', 'touchend',
    'contextmenu', 'wheel', 'keydown', 'keyup', 'keypress', 'input', 'beforeinput', 'paste', 'copy', 'cut', 'focusin', 'focusout']) {
    layer.addEventListener(t, (e) => e.stopPropagation())
  }
  // Press-and-hold on a touch screen opens the browser's menu; children press and hold.
  layer.addEventListener('contextmenu', (e) => { if (!e.target.closest('input')) e.preventDefault() })
  layer.addEventListener('dragstart', (e) => e.preventDefault())
  // Sound is allowed from the moment a finger lifts or a click lands, so wake the audio then too.
  for (const t of ['pointerup', 'click', 'touchend', 'keydown']) layer.addEventListener(t, unlockAudio, true)

  const ICON = {
    edit: '<svg viewBox="0 0 24 24"><path d="M4 17.5V20h2.5L17 9.5 14.5 7zM19.7 6.8a1 1 0 0 0 0-1.4l-1.1-1.1a1 1 0 0 0-1.4 0l-1.6 1.6 2.5 2.5z" fill="currentColor"/></svg>',
    close: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/></svg>',
    plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M8 5.5v13l10.5-6.5z" fill="currentColor"/></svg>',
    lock: '<svg viewBox="0 0 24 24"><rect x="5" y="10.5" width="14" height="10" rx="2" fill="currentColor"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" stroke="currentColor" stroke-width="2.2" fill="none"/></svg>',
    camera: '<svg viewBox="0 0 24 24"><path d="M4 8h3l1.5-2h7L17 8h3v11H4z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="12" cy="13" r="3.3" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
    words: '<svg viewBox="0 0 24 24"><rect x="2.5" y="8" width="5" height="8" rx="1.2" fill="currentColor"/><rect x="9.5" y="8" width="5" height="8" rx="1.2" fill="currentColor" opacity=".7"/><rect x="16.5" y="8" width="5" height="8" rx="1.2" fill="currentColor" opacity=".45"/></svg>',
    left: '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" stroke="currentColor" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    right: '<svg viewBox="0 0 24 24"><path d="M9 5l7 7-7 7" stroke="currentColor" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    speaker: '<svg viewBox="0 0 24 24"><path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z" fill="currentColor"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18 6a8.5 8.5 0 0 1 0 12" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>',
    mic: '<svg viewBox="0 0 24 24"><rect x="9" y="3.5" width="6" height="11" rx="3" fill="currentColor"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>',
  }
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])

  /* ---------- rendering ---------- */
  function render() {
    host.style.display = record.hidden ? 'none' : 'block'
    layer.dataset.mode = mode
    updateFrame()
    renderButtons()
    renderStrip()
    renderToolbar()
  }

  function pictureHtml(src) {
    return src ? `<img class="pic" src="${esc(src)}" alt="" draggable="false">` : ''
  }

  function renderButtons() {
    elButtons.textContent = ''
    for (const b of buttons()) {
      const el = document.createElement('div')
      el.className = 'cb' + (b.picture ? '' : ' no-pic') + (b.label ? '' : ' no-label')
      el.dataset.id = b.id
      el.setAttribute('role', 'button')
      el.tabIndex = 0
      el.setAttribute('aria-label', b.label || b.say || 'button')
      el.style.cssText = `left:${b.x * 100}%;top:${b.y * 100}%;width:${b.w * 100}%;height:${b.h * 100}%;--bg:${C.categoryColor(b.category)}`
      el.innerHTML = `${pictureHtml(b.picture)}<span class="label">${esc(b.label)}</span>`
      if (mode === 'edit') {
        el.insertAdjacentHTML('beforeend', `<button class="tool t-edit" type="button" aria-label="Change ${esc(b.label)}">${ICON.edit}</button>
          <button class="tool t-del" type="button" aria-label="Delete ${esc(b.label)}">${ICON.close}</button>
          <span class="grip" aria-hidden="true"></span>`)
        wireEditButton(el, b)
      } else {
        onPress(el, () => speak(b))
      }
      elButtons.appendChild(el)
    }
  }

  function renderStrip() {
    elStrip.hidden = !record.core
    elStrip.className = 'strip edge-' + (record.coreEdge || 'bottom')
    if (!record.core || elStrip.childElementCount) return
    for (const [slug, label, category] of C.CORE) {
      const el = document.createElement('div')
      el.className = 'core'
      el.dataset.slug = slug
      el.setAttribute('role', 'button')
      el.tabIndex = 0
      el.setAttribute('aria-label', label)
      el.style.setProperty('--bg', C.categoryColor(category))
      el.innerHTML = `${pictureHtml(corePics[slug])}<span class="label">${esc(label)}</span>`
      onPress(el, () => speak({ id: 'core-' + slug, label, say: label, category }))
      elStrip.appendChild(el)
    }
  }

  function renderToolbar() {
    elHandle.innerHTML = mode === 'edit' ? ICON.edit : ICON.lock
    elHandle.setAttribute('aria-label', mode === 'edit' ? 'Show or hide the button tools' : 'Hold to change the buttons')
    elToolbar.hidden = mode !== 'edit' || !toolbarOpen
    if (elToolbar.hidden) return
    const set = currentSet()
    let setRow
    if (usingSlides()) {
      setRow = `<div class="setname" title="Buttons change with each slide">This slide · ${buttons().length} button${buttons().length === 1 ? '' : 's'}</div>`
    } else {
      const m = manualSets()
      const n = m.length ? (record.setIndex | 0) + 1 : 0
      setRow = `<button class="tb icon" data-act="prev" type="button" aria-label="Previous set" ${n > 1 ? '' : 'disabled'}>${ICON.left}</button>
        <div class="setname">${esc(set?.name || 'Set 1')} <small>${n || 1} of ${Math.max(1, m.length)}</small></div>
        <button class="tb icon" data-act="next" type="button" aria-label="Next set" ${n && n < m.length ? '' : 'disabled'}>${ICON.right}</button>
        <button class="tb icon" data-act="newset" type="button" aria-label="New set">${ICON.plus}</button>`
    }
    elToolbar.innerHTML = `
      <button class="tb primary" data-act="add" type="button">${ICON.plus}<span>Add a button</span></button>
      <button class="tb" data-act="grab" type="button">${ICON.camera}<span>Grab a picture</span></button>
      <button class="tb ${record.core ? 'on' : ''}" data-act="core" type="button" aria-pressed="${!!record.core}">${ICON.words}<span>Core words</span></button>
      <div class="setrow">${setRow}</div>
      ${isSlides && !slideId && record.perSlide ? '<div class="note">Can’t tell which slide is open, so these are a separate set. Open a slide to give it its own buttons.</div>' : ''}
      <button class="tb play" data-act="play" type="button">${ICON.play}<span>Done: play mode</span></button>`
    for (const b of elToolbar.querySelectorAll('[data-act]')) b.addEventListener('click', () => toolbarAction(b.dataset.act))
  }

  async function toolbarAction(act) {
    tick() // a slide change in the last moment counts before adding to "this slide"
    if (act === 'add') addButton()
    else if (act === 'grab') grab(null)
    else if (act === 'core') { record.core = !record.core; await save(); render() }
    else if (act === 'play') setMode('play')
    else if (act === 'prev' || act === 'next') { record.setIndex = (record.setIndex | 0) + (act === 'next' ? 1 : -1); await save(); render() }
    else if (act === 'newset') {
      const m = manualSets()
      record.sets.push({ name: `Set ${m.length + 1}`, buttons: [] })
      if (!m.length) record.sets.push({ name: 'Set 2', buttons: [] }) // the implied empty Set 1 becomes real too
      record.setIndex = manualSets().length - 1
      await save()
      render()
    }
  }

  function setMode(next) {
    mode = next === 'edit' ? 'edit' : 'play'
    if (mode === 'play') closeEditor(false)
    toolbarOpen = true
    render()
    if (mode === 'play') preload()
  }

  /* ---------- the handle: tap to fold the tools away; in play mode, hold to unlock ---------- */
  {
    let timer = null
    elHandle.addEventListener('pointerdown', (e) => {
      if (e.button > 0) return
      if (mode === 'edit') { toolbarOpen = !toolbarOpen; renderToolbar(); return }
      elHandle.classList.add('holding')
      timer = setTimeout(() => { timer = null; elHandle.classList.remove('holding'); setMode('edit') }, 900)
    })
    const cancel = () => {
      if (!timer) return
      clearTimeout(timer)
      timer = null
      elHandle.classList.remove('holding')
      elTip.textContent = 'Hold to change the buttons'
      elTip.classList.add('show')
      setTimeout(() => elTip.classList.remove('show'), 1800)
    }
    elHandle.addEventListener('pointerup', cancel)
    elHandle.addEventListener('pointerleave', cancel)
    elHandle.addEventListener('pointercancel', cancel)
    elHandle.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setMode(mode === 'edit' ? 'play' : 'edit') } })
  }

  /* ---------- edit mode: drag, resize, change, delete ---------- */
  function wireEditButton(el, b) {
    el.querySelector('.t-edit').addEventListener('click', () => openEditor(b.id))
    el.querySelector('.t-del').addEventListener('click', () => removeButton(b.id))
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openEditor(b.id) } })
    const grip = el.querySelector('.grip')
    el.addEventListener('pointerdown', (e) => {
      if (e.button > 0 || e.target.closest('.tool')) return
      e.preventDefault()
      const resize = e.target === grip
      const r = elButtons.getBoundingClientRect() // the slide, or the window when there's no slide
      const start = { px: e.clientX, py: e.clientY, x: b.x, y: b.y, w: b.w, h: b.h }
      let moved = false
      busy++
      el.setPointerCapture(e.pointerId)
      el.classList.add('dragging')
      const move = (ev) => {
        const dx = (ev.clientX - start.px) / r.width
        const dy = (ev.clientY - start.py) / r.height
        if (!moved && Math.hypot(ev.clientX - start.px, ev.clientY - start.py) < 6) return
        moved = true
        if (resize) {
          b.w = C.clamp(start.w + dx, Math.max(0.03, 48 / r.width), 1 - b.x)
          b.h = C.clamp(start.h + dy, Math.max(0.04, 48 / r.height), 1 - b.y)
          el.style.width = b.w * 100 + '%'
          el.style.height = b.h * 100 + '%'
        } else {
          b.x = C.clamp(start.x + dx, 0, 1 - b.w)
          b.y = C.clamp(start.y + dy, 0, 1 - b.h)
          el.style.left = b.x * 100 + '%'
          el.style.top = b.y * 100 + '%'
        }
      }
      const up = async () => {
        el.removeEventListener('pointermove', move)
        el.removeEventListener('pointerup', up)
        el.removeEventListener('pointercancel', up)
        el.classList.remove('dragging')
        busy--
        if (moved) await save()
        else if (!resize) openEditor(b.id)
        if (!busy && pendingRecord) { const p = pendingRecord; pendingRecord = null; adopt(p) }
      }
      el.addEventListener('pointermove', move)
      el.addEventListener('pointerup', up)
      el.addEventListener('pointercancel', up)
    })
  }

  function newButtonAt(rect) {
    const set = currentSet(true)
    const r = elButtons.getBoundingClientRect()
    let w, h, x, y
    if (rect) ({ x, y, w, h } = rect)
    else {
      // The first free spot in rows across the upper part of the screen, so new buttons don't pile up.
      h = 0.2
      w = Math.min(0.3, (h * r.height) / r.width)
      const free = (px, py) => set.buttons.every((o) => px + w <= o.x || o.x + o.w <= px || py + h <= o.y || o.y + o.h <= py)
      const spots = []
      for (const row of [0.3, 0.06, 0.54]) for (let col = 0.3; col + w <= 0.97; col += w + 0.02) spots.push([col, row])
      const spot = spots.find(([px, py]) => free(px, py)) || [0.3 + (set.buttons.length % 6) * 0.03, 0.3 + (set.buttons.length % 6) * 0.03]
      ;[x, y] = [C.clamp(spot[0], 0, 1 - w), C.clamp(spot[1], 0, 1 - h)]
    }
    const b = { id: C.newId(), label: '', say: '', category: 'noun', picture: null, clip: null, x, y, w, h }
    set.buttons.push(b)
    return b
  }
  function addButton() {
    const b = newButtonAt(null)
    render()
    openEditor(b.id, true)
  }
  async function removeButton(id) {
    const set = currentSet()
    const i = set?.buttons.findIndex((b) => b.id === id) ?? -1
    if (i < 0) return
    const [gone] = set.buttons.splice(i, 1)
    await save()
    render()
    toast(`Deleted “${gone.label || 'button'}”.`, 'Undo', async () => {
      set.buttons.splice(i, 0, gone)
      await save()
      render()
    })
  }

  /* ---------- the button editor ---------- */
  function openEditor(id, isNew = false) {
    const b = findButton(id)
    if (!b) return
    editor = { id, isNew, draft: { ...b }, results: null, query: b.picture ? '' : b.label }
    elDialog.hidden = false
    renderEditor()
    const first = elDialog.querySelector(isNew ? '[name=q]' : '[name=label]')
    first?.focus()
  }
  function closeEditor(keep) {
    if (!editor) return
    const { id, isNew, draft } = editor
    editor = null
    elDialog.hidden = true
    elDialog.textContent = ''
    // Look in every set: the slide may have changed since the editor opened.
    const set = record.sets.find((x) => x.buttons.some((b) => b.id === id))
    if (!set) { render(); return }
    const i = set.buttons.findIndex((b) => b.id === id)
    const blank = !draft.label.trim() && !(draft.say || '').trim() && !draft.picture && !draft.clip
    if (keep && !(isNew && blank)) {
      const b = set.buttons[i]
      Object.assign(b, draft, { x: b.x, y: b.y, w: b.w, h: b.h })
      b.label = b.label.trim()
      b.say = (b.say || '').trim() || b.label
      save()
    } else if (isNew) {
      set.buttons.splice(i, 1) // a new button nobody filled in isn't left behind
      save()
    }
    render()
  }
  function voiceNote(d) {
    const v = voiceFor({ ...d, say: d.say || d.label })
    if (v.kind === 'recording') return 'Plays your recording.'
    if (v.kind === 'clip') return 'Plays the Calming Corner voice.'
    return (d.say || d.label) ? 'Uses the computer’s voice. Record your own if you like.' : ''
  }
  function renderEditor() {
    if (!editor) return
    const d = editor.draft
    const keepFocus = root.activeElement?.getAttribute('name')
    const caret = root.activeElement?.selectionStart
    elDialog.innerHTML = `
      <div class="dialog" role="dialog" aria-modal="true" aria-label="Change button">
        <div class="d-top">
          <div class="preview" style="--bg:${C.categoryColor(d.category)}">${pictureHtml(d.picture)}<span class="label">${esc(d.label)}</span></div>
          <div class="fields">
            <label>Words on the button<input name="label" value="${esc(d.label)}" maxlength="80" autocomplete="off" placeholder="scarf"></label>
            <label>It says<input name="say" value="${esc(d.say)}" maxlength="300" autocomplete="off" placeholder="${esc(d.label || 'Same as the words on the button')}"></label>
            <div class="voice"><span class="vnote">${esc(voiceNote(d))}</span></div>
            <div class="row">
              <button class="btn" data-act="hear" type="button">${ICON.speaker}<span>Hear it</span></button>
              <button class="btn" data-act="record" type="button" ${calmSlug(d) ? 'hidden' : ''}>${ICON.mic}<span>${d.clip ? 'Record again' : 'Record my voice'}</span></button>
              ${d.clip ? '<button class="btn quiet" data-act="unrecord" type="button">Remove recording</button>' : ''}
            </div>
          </div>
        </div>
        <div class="cats" role="radiogroup" aria-label="Colour">
          ${C.CATEGORIES.map((c) => `<button type="button" role="radio" class="cat" data-cat="${c.key}" aria-checked="${d.category === c.key}" style="--bg:${c.color}">${esc(c.name)}</button>`).join('')}
        </div>
        <div class="picture-tools">
          <form class="search"><input name="q" value="${esc(editor.query || '')}" placeholder="Find a picture: scarf, coat, put on…" autocomplete="off" aria-label="Find a picture"><button class="btn" type="submit">Find</button></form>
          <button class="btn" data-act="grab" type="button">${ICON.camera}<span>Grab from the page</span></button>
          ${d.picture ? '<button class="btn quiet" data-act="nopic" type="button">No picture</button>' : ''}
        </div>
        <div class="results">${editor.results === null ? '' : editor.results.length
          ? editor.results.map((r, i) => `<button type="button" class="result" data-i="${i}" title="${esc(r.label)}"><img src="${esc(r.picture)}" alt="${esc(r.label)}" draggable="false"></button>`).join('')
          : '<p class="none">No pictures found. Try a simpler word.</p>'}</div>
        <div class="d-bottom">
          <button class="btn danger" data-act="delete" type="button">Delete button</button>
          <span class="grow"></span>
          <button class="btn" data-act="cancel" type="button">Cancel</button>
          <button class="btn primary" data-act="save" type="button">Save</button>
        </div>
        <p class="credit">Pictures: Mulberry Symbols and OpenMoji, CC BY-SA 4.0.</p>
      </div>`
    const dlg = elDialog.querySelector('.dialog')
    for (const inp of dlg.querySelectorAll('input[name=label], input[name=say]')) {
      inp.addEventListener('input', () => {
        d[inp.name] = inp.value
        dlg.querySelector('.vnote').textContent = voiceNote(d)
        dlg.querySelector('[data-act=record]').hidden = !!calmSlug(d) // the calm voice already says it
        const pl = dlg.querySelector('.preview .label')
        pl.textContent = d.label
        if (inp.name === 'label') dlg.querySelector('input[name=say]').placeholder = d.label || 'Same as the words on the button'
      })
    }
    dlg.querySelector('input[name=q]').addEventListener('input', (e) => { editor.query = e.target.value })
    dlg.querySelector('form.search').addEventListener('submit', async (e) => {
      e.preventDefault()
      const q = editor.query.trim()
      if (!q) return
      dlg.querySelector('.results').innerHTML = '<p class="none">Looking…</p>'
      const results = await value('search', { q })
      if (!editor) return
      editor.results = results || []
      renderEditor()
    })
    for (const el of dlg.querySelectorAll('.result')) {
      el.addEventListener('click', () => {
        const r = editor.results[+el.dataset.i]
        d.picture = r.picture
        if (!d.label.trim()) d.label = r.label
        renderEditor()
      })
    }
    for (const el of dlg.querySelectorAll('.cat')) el.addEventListener('click', () => { d.category = el.dataset.cat; renderEditor() })
    for (const el of dlg.querySelectorAll('[data-act]')) el.addEventListener('click', () => editorAction(el.dataset.act))
    dlg.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeEditor(false) })
    if (keepFocus) {
      const f = dlg.querySelector(`[name=${keepFocus}]`)
      if (f) { f.focus(); try { f.setSelectionRange(caret, caret) } catch { /* not a text field */ } }
    }
  }
  async function editorAction(act) {
    const d = editor.draft
    if (act === 'save') closeEditor(true)
    else if (act === 'cancel') closeEditor(false)
    else if (act === 'delete') { const id = editor.id; closeEditor(false); removeButton(id) }
    else if (act === 'hear') speak({ ...d, say: d.say || d.label })
    else if (act === 'nopic') { d.picture = null; renderEditor() }
    else if (act === 'unrecord') { d.clip = null; renderEditor() }
    else if (act === 'grab') grab(editor)
    else if (act === 'record') {
      // Recording happens in an extension tab, so the microphone prompt names the extension,
      // not the activity's website. The recording comes back through storage.
      const b = record.sets.flatMap((s) => s.buttons).find((x) => x.id === editor.id)
      if (!b) return
      Object.assign(b, d, { x: b.x, y: b.y, w: b.w, h: b.h })
      editor.isNew = false
      await save()
      const r = await send('openPage', { page: 'record', params: { key, id: b.id, label: (d.say || d.label || '').trim() } })
      if (!r.ok) toast('Could not open the recording page.')
    }
  }

  /* ---------- grab a picture from the page ---------- */
  async function grab(forEditor) {
    host.style.visibility = 'hidden'
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(r, 60))))
    const shot = await send('capture')
    host.style.visibility = ''
    if (!shot.ok || !shot.value) {
      toast('To grab a picture, click the Talking Buttons icon in the browser toolbar, then choose “Grab a picture”.')
      return
    }
    if (mode !== 'edit') setMode('edit')
    elDialog.hidden = true
    const r = layer.getBoundingClientRect()
    elCrop.hidden = false
    elCrop.innerHTML = `<img class="shot" src="${shot.value}" alt="" draggable="false"><div class="box" hidden></div>
      <div class="crop-bar"><span>Drag a box around the picture you want.</span>
      <button class="btn" data-act="cancel" type="button">Cancel</button><button class="btn primary" data-act="use" type="button" disabled>Use this picture</button></div>`
    elCrop.classList.add('empty')
    const box = elCrop.querySelector('.box')
    const use = elCrop.querySelector('[data-act=use]')
    const listening = new AbortController()
    let sel = null
    elCrop.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.crop-bar')) return
      e.preventDefault()
      elCrop.setPointerCapture(e.pointerId)
      const x0 = e.clientX - r.left
      const y0 = e.clientY - r.top
      const move = (ev) => {
        const x1 = C.clamp(ev.clientX - r.left, 0, r.width)
        const y1 = C.clamp(ev.clientY - r.top, 0, r.height)
        sel = { x: Math.min(x0, x1), y: Math.min(y0, y1), w: Math.abs(x1 - x0), h: Math.abs(y1 - y0) }
        Object.assign(box.style, { left: sel.x + 'px', top: sel.y + 'px', width: sel.w + 'px', height: sel.h + 'px' })
        box.hidden = false
        elCrop.classList.remove('empty')
        use.disabled = sel.w < 12 || sel.h < 12
      }
      const up = () => { elCrop.removeEventListener('pointermove', move); elCrop.removeEventListener('pointerup', up) }
      elCrop.addEventListener('pointermove', move)
      elCrop.addEventListener('pointerup', up)
    }, { signal: listening.signal })
    const done = () => { listening.abort(); elCrop.hidden = true; elCrop.textContent = '' }
    elCrop.querySelector('[data-act=cancel]').addEventListener('click', () => {
      done()
      if (forEditor && editor) elDialog.hidden = false
    })
    use.addEventListener('click', async () => {
      const img = elCrop.querySelector('.shot')
      const sx = img.naturalWidth / r.width
      const sy = img.naturalHeight / r.height
      const scale = Math.min(1, 360 / Math.max(sel.w * sx, sel.h * sy))
      const canvas = document.createElement('canvas')
      canvas.width = Math.max(1, Math.round(sel.w * sx * scale))
      canvas.height = Math.max(1, Math.round(sel.h * sy * scale))
      canvas.getContext('2d').drawImage(img, sel.x * sx, sel.y * sy, sel.w * sx, sel.h * sy, 0, 0, canvas.width, canvas.height)
      const picture = canvas.toDataURL('image/png')
      // Where the picture was, as fractions of the slide the buttons are placed on.
      const f = elButtons.getBoundingClientRect()
      const fx = sel.x + r.left - f.left
      const fy = sel.y + r.top - f.top
      const frac = { x: fx / f.width, y: fy / f.height, w: Math.max(sel.w, 64) / f.width, h: Math.max(sel.h, 64) / f.height }
      done()
      if (forEditor && editor) {
        editor.draft.picture = picture
        elDialog.hidden = false
        renderEditor()
      } else {
        // A new button exactly where the picture was, ready to be named.
        frac.w = Math.min(frac.w, 1); frac.h = Math.min(frac.h, 1)
        frac.x = C.clamp(frac.x, 0, 1 - frac.w); frac.y = C.clamp(frac.y, 0, 1 - frac.h)
        const b = newButtonAt(frac)
        b.picture = picture
        render()
        openEditor(b.id, true)
        elDialog.querySelector('[name=label]')?.focus()
      }
    })
  }

  /* ---------- toast ---------- */
  let toastTimer
  function toast(text, action, fn) {
    elToast.innerHTML = `<span>${esc(text)}</span>${action ? `<button class="btn" type="button">${esc(action)}</button>` : ''}`
    elToast.hidden = false
    if (action) elToast.querySelector('button').addEventListener('click', () => { elToast.hidden = true; fn() })
    clearTimeout(toastTimer)
    toastTimer = setTimeout(() => { elToast.hidden = true }, action ? 7000 : 5000)
  }

  /* ---------- where the layer lives: full screen and present mode ---------- */
  // Fixed elements outside document.fullscreenElement are not drawn, so while something is full screen
  // the layer moves inside it, including into a same-origin present-mode iframe.
  function mountTarget(doc = document, depth = 0) {
    const fe = doc.fullscreenElement || doc.webkitFullscreenElement
    if (!fe) return doc.documentElement
    if (fe.tagName === 'IFRAME' || fe.tagName === 'FRAME') {
      let inner = null
      try { inner = fe.contentDocument } catch { /* cross-origin */ }
      return inner?.documentElement && depth < 4 ? mountTarget(inner, depth + 1) : null
    }
    if (/^(VIDEO|IMG|CANVAS|SVG|INPUT|TEXTAREA)$/i.test(fe.tagName)) return null
    return fe
  }
  function mount() {
    const target = mountTarget()
    if (!target) return
    if (host.parentNode !== target) target.appendChild(host)
    debug.mountedIn = target === document.documentElement ? 'page' : (target.ownerDocument === document ? 'fullscreen' : 'frame')
    updateFrame()
  }
  document.addEventListener('fullscreenchange', mount)
  document.addEventListener('webkitfullscreenchange', mount)

  /* ---------- the slide: buttons are placed on it, not on the window ---------- */
  // The same slide sits in a different place in the editor (filmstrip, toolbars, notes) than when
  // presenting, and the board and the laptop have different shapes. So on Google Slides, button
  // positions are fractions of the slide itself. Slides draws the slide as a large SVG in the
  // usual slide shapes; when none is found, positions fall back to fractions of the window.
  const SHAPES = [16 / 9, 16 / 10, 4 / 3, 297 / 210, 11 / 8.5]
  let slideEl = null
  let slideSearched = 0
  function slideArea(el, view) {
    if (!el?.isConnected) return 0
    const r = el.getBoundingClientRect()
    if (r.width < 160 || r.height < 90) return 0
    const ratio = r.width / r.height
    if (!SHAPES.some((q) => Math.abs(ratio - q) / q < 0.025)) return 0
    const seen = Math.max(0, Math.min(r.right, view.innerWidth) - Math.max(r.left, 0)) * Math.max(0, Math.min(r.bottom, view.innerHeight) - Math.max(r.top, 0))
    return seen >= 0.12 * view.innerWidth * view.innerHeight ? r.width * r.height : 0
  }
  function findSlide() {
    if (!isSlides || !host.isConnected) return null
    const doc = host.ownerDocument
    const view = doc.defaultView
    const now = performance.now()
    if (slideEl?.ownerDocument === doc && slideArea(slideEl, view) && now - slideSearched < 2000) return slideEl
    slideSearched = now
    let best = null
    let bestArea = 0
    for (const el of doc.querySelectorAll('svg')) {
      const a = slideArea(el, view)
      if (a > bestArea) { best = el; bestArea = a }
    }
    return (slideEl = best)
  }
  let frameKey = ''
  function updateFrame() {
    const el = findSlide()
    const r = el?.getBoundingClientRect()
    const next = r ? `${r.left},${r.top},${r.width},${r.height}` : 'window'
    if (next === frameKey) return
    frameKey = next
    Object.assign(elButtons.style, r
      ? { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px', right: 'auto', bottom: 'auto' }
      : { left: '0', top: '0', width: '100%', height: '100%', right: 'auto', bottom: 'auto' })
  }
  let frameQueued = false
  const queueFrame = () => {
    if (frameQueued) return
    frameQueued = true
    requestAnimationFrame(() => { frameQueued = false; updateFrame() })
  }
  window.addEventListener('resize', queueFrame)
  document.addEventListener('scroll', queueFrame, true)

  /* ---------- slide changes ---------- */
  function currentSlide() {
    let s = C.slidesInfo(location.href)?.slide || null
    if (!s) {
      // Present mode can run inside a same-origin iframe; look at its address too.
      const fe = document.fullscreenElement
      try { if (fe?.tagName === 'IFRAME') s = C.slidesInfo(new URL(fe.contentWindow.location.href, location.href).href)?.slide || null } catch { /* cross-origin */ }
    }
    return s
  }
  let lastHref = ''
  function tick() {
    mount()
    updateFrame()
    if (!isSlides) return
    const href = location.href
    const s = currentSlide()
    if (href === lastHref && s === slideId) return
    lastHref = href
    if (s !== slideId) {
      if (editor) closeEditor(true) // while "this slide" still means the slide it was opened on
      slideId = s
      render()
      if (mode === 'play') preload()
    }
  }
  window.addEventListener('hashchange', tick)
  window.addEventListener('popstate', tick)
  setInterval(tick, 400) // history.replaceState fires no event, so also look regularly

  /* ---------- the popup talks to the page through these ---------- */
  function state() {
    const set = currentSet()
    return {
      key, isSlides, slideId, mode, title: record.title || pageTitle(),
      core: !!record.core, coreEdge: record.coreEdge || 'bottom', perSlide: !!record.perSlide, hidden: !!record.hidden,
      setName: usingSlides() ? 'This slide' : set?.name || 'Set 1', buttonCount: buttons().length,
      totalButtons: record.sets.reduce((n, s) => n + s.buttons.length, 0),
      placedOn: frameKey && frameKey !== 'window' ? 'slide' : 'window',
      debug: { ...debug, audio: ctx?.state || 'none' },
    }
  }
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (sender.id !== chrome.runtime.id || !String(sender.url || '').startsWith(chrome.runtime.getURL(''))) return false
    ;(async () => {
      await ready
      if (msg.type === 'state') return state()
      if (msg.type === 'setMode') { if (record.hidden) { record.hidden = false; await save() } setMode(msg.mode); return state() }
      if (msg.type === 'setOption') {
        for (const k of ['core', 'coreEdge', 'perSlide', 'hidden']) if (k in msg) record[k] = msg[k]
        if (!record.title) record.title = pageTitle()
        await save()
        render()
        if (mode === 'play') preload()
        return state()
      }
      if (msg.type === 'grab') { if (record.hidden) { record.hidden = false; await save(); render() } setTimeout(() => grab(null), 150); return true }
      if (msg.type === 'export') return C.toFile({ ...record, title: record.title || pageTitle() })
      return null
    })().then(reply)
    return true
  })

  /* ---------- start ---------- */
  api.reveal = () => { mount(); render() }
  const ready = (async () => {
    const [stored, list, pics] = await Promise.all([
      chrome.storage.local.get(key).then((r) => r[key]).catch(() => null),
      value('clipIndex'),
      value('core'),
    ])
    clipList = new Set(list || [])
    corePics = pics || {}
    if (stored) adopt(stored)
    slideId = isSlides ? currentSlide() : null
    lastHref = location.href
    mount()
    render()
    preload()
  })()

  function CSS() {
    return `
    :host { all: initial; }
    * { box-sizing: border-box; }
    [hidden] { display: none !important; }
    .layer { position: absolute; inset: 0; pointer-events: none; font: 16px/1.3 "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; color: #1f2328;
      -webkit-user-select: none; user-select: none; -webkit-tap-highlight-color: transparent; }
    .buttons { position: absolute; inset: 0; }

    /* Talking buttons */
    .cb, .core { pointer-events: auto; touch-action: none; position: absolute; display: flex; flex-direction: column; align-items: center;
      justify-content: center; gap: 2%; padding: 6px; background: var(--bg, #fff); border: 3px solid #2b2f36; border-radius: 16px;
      box-shadow: 0 3px 0 rgba(0,0,0,.28), 0 6px 18px rgba(0,0,0,.18); cursor: pointer; min-width: 48px; min-height: 48px;
      container-type: size; transition: transform .12s ease, filter .12s ease; outline: none; }
    .cb:focus-visible, .core:focus-visible { box-shadow: 0 0 0 4px #2f6fde; }
    .cb .pic, .core .pic { flex: 1 1 auto; min-height: 0; width: 100%; object-fit: contain; pointer-events: none; }
    .label { flex: none; max-width: 100%; font-weight: 700; text-align: center; line-height: 1.05; overflow: hidden; text-overflow: ellipsis;
      white-space: nowrap; font-size: clamp(12px, 15cqh, 44px); }
    .cb.no-pic .label { white-space: normal; font-size: clamp(14px, 26cqh, 64px); }
    .cb.no-label .label { display: none; }
    .pressed { transform: scale(.93); filter: brightness(.9); }

    [data-mode=edit] .cb { cursor: grab; outline: 3px dashed #2f6fde; outline-offset: 3px; }
    [data-mode=edit] .cb.dragging { cursor: grabbing; opacity: .85; }
    .tool { position: absolute; top: -18px; width: 36px; height: 36px; border-radius: 50%; border: 2px solid #2b2f36; background: #fff;
      display: grid; place-items: center; padding: 6px; cursor: pointer; color: #1f2328; box-shadow: 0 2px 6px rgba(0,0,0,.25); }
    .tool svg { width: 100%; height: 100%; }
    .t-edit { left: -18px; } .t-del { right: -18px; color: #b42318; }
    .grip { position: absolute; right: -4px; bottom: -4px; width: 30px; height: 30px; cursor: nwse-resize; border-radius: 0 0 14px 0;
      background: linear-gradient(135deg, transparent 50%, #2f6fde 50%); }

    /* Core-word strip */
    .strip { position: absolute; display: flex; gap: 6px; padding: 6px; pointer-events: none; }
    .strip.edge-bottom, .strip.edge-top { left: 50%; transform: translateX(-50%); max-width: calc(100% - 140px); }
    .strip.edge-bottom { bottom: 8px; } .strip.edge-top { top: 8px; }
    .strip.edge-left, .strip.edge-right { top: 50%; transform: translateY(-50%); flex-direction: column; max-height: calc(100% - 16px); }
    .strip.edge-left { left: 8px; } .strip.edge-right { right: 8px; }
    .core { position: relative; flex: none; width: clamp(56px, min(8.4vw, 11vh), 120px); height: clamp(56px, min(8.4vw, 11vh), 120px); border-radius: 12px; padding: 4px; }
    .edge-left .core, .edge-right .core { width: clamp(52px, min(8vh, 9vw), 96px); height: clamp(52px, min(8vh, 9vw), 96px); }

    /* Handle and tools */
    .dock { position: absolute; right: 10px; bottom: 10px; display: flex; flex-direction: column; align-items: flex-end; gap: 8px; pointer-events: none; }
    .handle { pointer-events: auto; touch-action: none; width: 44px; height: 44px; border-radius: 50%; border: 2px solid #2b2f36; background: #fff; color: #1f2328;
      display: grid; place-items: center; padding: 10px; cursor: pointer; opacity: .45; box-shadow: 0 2px 8px rgba(0,0,0,.25); position: relative; }
    .handle:hover, .handle:focus-visible, [data-mode=edit] .handle { opacity: 1; }
    [data-mode=edit] .handle { background: #2f6fde; color: #fff; border-color: #1d4fa8; }
    .handle svg { width: 100%; height: 100%; }
    .handle.holding { opacity: 1; }
    .handle.holding::after { content: ""; position: absolute; inset: -6px; border-radius: 50%; border: 4px solid #2f6fde; animation: hold .9s linear forwards;
      clip-path: inset(0 0 0 0); }
    @keyframes hold { from { transform: scale(1.4); opacity: .2; } to { transform: scale(1); opacity: 1; } }
    .tip { position: absolute; right: 52px; bottom: 6px; background: #1f2328; color: #fff; padding: 8px 12px; border-radius: 10px; font-size: 15px;
      white-space: nowrap; opacity: 0; transition: opacity .2s; pointer-events: none; }
    .tip.show { opacity: 1; }
    .toolbar { pointer-events: auto; background: #fff; border: 2px solid #2b2f36; border-radius: 16px; padding: 8px; display: flex; flex-direction: column;
      gap: 6px; box-shadow: 0 8px 28px rgba(0,0,0,.25); width: 236px; }
    .tb { display: flex; align-items: center; gap: 10px; min-height: 48px; padding: 6px 12px; border: 2px solid #c9ced6; border-radius: 12px; background: #fff;
      color: #1f2328; font: inherit; font-weight: 600; cursor: pointer; text-align: left; }
    .tb svg { width: 24px; height: 24px; flex: none; }
    .tb.primary { background: #2f6fde; color: #fff; border-color: #1d4fa8; }
    .tb.on { background: #d8eed3; border-color: #3d8a35; }
    .tb.play { background: #1f2328; color: #fff; border-color: #1f2328; }
    .tb:disabled { opacity: .35; cursor: default; }
    .tb.icon { padding: 6px; min-width: 44px; justify-content: center; }
    .setrow { display: flex; align-items: center; gap: 4px; }
    .setname { flex: 1; font-weight: 600; text-align: center; font-size: 14px; }
    .setname small { display: block; font-weight: 400; color: #5b6470; }
    .note { font-size: 13px; color: #5b6470; padding: 0 4px; }

    /* Editor */
    .dialog-wrap { position: absolute; inset: 0; display: grid; place-items: center; background: rgba(20,24,30,.35); pointer-events: auto; padding: 16px; }
    .dialog { background: #fff; border-radius: 20px; border: 2px solid #2b2f36; width: min(640px, 100%); max-height: 100%; overflow: auto; padding: 18px;
      display: flex; flex-direction: column; gap: 14px; box-shadow: 0 20px 60px rgba(0,0,0,.35); -webkit-user-select: text; user-select: text; }
    .d-top { display: flex; gap: 16px; align-items: flex-start; }
    .preview { position: relative; flex: none; width: 130px; height: 130px; display: flex; flex-direction: column; align-items: center; justify-content: center;
      padding: 6px; background: var(--bg); border: 3px solid #2b2f36; border-radius: 16px; container-type: size; }
    .preview .pic { flex: 1 1 auto; min-height: 0; width: 100%; object-fit: contain; }
    .fields { flex: 1; display: flex; flex-direction: column; gap: 10px; min-width: 0; }
    label { display: flex; flex-direction: column; gap: 4px; font-weight: 600; font-size: 14px; }
    input { font: inherit; font-size: 18px; padding: 10px 12px; border: 2px solid #c9ced6; border-radius: 10px; min-height: 48px; width: 100%; color: #1f2328; background: #fff; }
    input:focus { outline: none; border-color: #2f6fde; }
    .voice { font-size: 14px; color: #3d8a35; min-height: 18px; }
    .row, .picture-tools, .d-bottom { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
    .search { display: flex; gap: 8px; flex: 1 1 260px; }
    .btn { display: inline-flex; align-items: center; gap: 8px; min-height: 48px; padding: 8px 16px; border: 2px solid #c9ced6; border-radius: 12px; background: #fff;
      color: #1f2328; font: inherit; font-weight: 600; cursor: pointer; }
    .btn svg { width: 22px; height: 22px; }
    .btn.primary { background: #2f6fde; border-color: #1d4fa8; color: #fff; }
    .btn.danger { color: #b42318; border-color: #f0b7b0; }
    .btn.quiet { border-color: transparent; color: #5b6470; }
    .btn:disabled { opacity: .4; cursor: default; }
    .grow { flex: 1; }
    .cats { display: flex; flex-wrap: wrap; gap: 6px; }
    .cat { min-height: 40px; padding: 6px 12px; border-radius: 10px; border: 2px solid #c9ced6; background: var(--bg); font: inherit; font-size: 14px; cursor: pointer; color: #1f2328; }
    .cat[aria-checked=true] { border-color: #2b2f36; box-shadow: inset 0 0 0 2px #2b2f36; font-weight: 700; }
    .results { display: grid; grid-template-columns: repeat(auto-fill, minmax(76px, 1fr)); gap: 6px; max-height: 260px; overflow: auto; }
    .results:empty { display: none; }
    .result { aspect-ratio: 1; border: 2px solid #e1e4e8; border-radius: 10px; background: #fff; padding: 6px; cursor: pointer; }
    .result:hover, .result:focus-visible { border-color: #2f6fde; }
    .result img { width: 100%; height: 100%; object-fit: contain; }
    .none { grid-column: 1 / -1; color: #5b6470; margin: 4px 0; }
    .credit { margin: 0; font-size: 12px; color: #7b8490; }

    /* Crop */
    .crop { position: absolute; inset: 0; pointer-events: auto; cursor: crosshair; touch-action: none; background: #000; }
    .crop .shot { position: absolute; inset: 0; width: 100%; height: 100%; }
    .crop.empty .shot { filter: brightness(.65); }
    .crop .box { position: absolute; border: 3px solid #fff; outline: 2px solid #2f6fde; box-shadow: 0 0 0 9999px rgba(0,0,0,.35);
      background: transparent; }
    .crop-bar { position: absolute; left: 50%; top: 16px; transform: translateX(-50%); display: flex; gap: 10px; align-items: center; background: #fff;
      border-radius: 16px; padding: 8px 8px 8px 16px; box-shadow: 0 8px 28px rgba(0,0,0,.35); cursor: default; font-weight: 600; }

    /* Toast */
    .toast { position: absolute; left: 50%; bottom: 24px; transform: translateX(-50%); background: #1f2328; color: #fff; border-radius: 14px;
      padding: 10px 12px 10px 18px; display: flex; gap: 12px; align-items: center; pointer-events: auto; max-width: min(560px, calc(100% - 32px));
      box-shadow: 0 8px 28px rgba(0,0,0,.35); }
    .toast .btn { min-height: 40px; }
    `
  }
})()
