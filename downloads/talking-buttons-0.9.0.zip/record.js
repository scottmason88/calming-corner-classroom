/* Records a teacher's voice for one button. This runs on an extension page so the
   microphone prompt names the extension, not docs.google.com or the activity's site. */
const params = new URLSearchParams(location.search)
const key = params.get('key')
const id = params.get('id')
const $ = (x) => document.getElementById(x)
$('word').textContent = params.get('label') || 'this button'

let recorder = null
let stream = null
let blob = null
let stopTimer = null

async function start() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } })
  } catch {
    $('status').textContent = 'The microphone is blocked. Allow it in the address bar, then try again.'
    return
  }
  const type = ['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/webm'].find((t) => MediaRecorder.isTypeSupported(t)) || ''
  recorder = new MediaRecorder(stream, type ? { mimeType: type } : undefined)
  const parts = []
  recorder.ondataavailable = (e) => e.data.size && parts.push(e.data)
  recorder.onstop = () => {
    stream.getTracks().forEach((t) => t.stop())
    blob = new Blob(parts, { type: recorder.mimeType || 'audio/webm' })
    recorder = null
    $('rec').classList.remove('on')
    $('rec').textContent = 'Again'
    $('listen').disabled = $('save').disabled = !blob.size
    $('status').textContent = blob.size ? 'Listen, then use it or record again.' : 'Nothing was recorded. Try again.'
  }
  recorder.start()
  $('rec').classList.add('on')
  $('rec').textContent = 'Stop'
  $('status').textContent = 'Recording…'
  stopTimer = setTimeout(stop, 8000)
}
function stop() {
  clearTimeout(stopTimer)
  if (recorder?.state === 'recording') recorder.stop()
}

$('rec').addEventListener('click', () => (recorder ? stop() : start()))
$('listen').addEventListener('click', () => { if (blob) new Audio(URL.createObjectURL(blob)).play() })
$('cancel').addEventListener('click', finish)
$('save').addEventListener('click', async () => {
  const b64 = await new Promise((resolve) => {
    const r = new FileReader()
    r.onload = () => resolve(String(r.result)) // keep the data:audio/webm;… prefix, as the book maker does
    r.readAsDataURL(blob)
  })
  const record = (await chrome.storage.local.get(key))[key]
  const button = record?.sets?.flatMap((s) => s.buttons).find((b) => b.id === id)
  if (!button) { $('status').textContent = 'That button is gone. Was it deleted?'; return }
  button.clip = b64
  record.updated = Date.now()
  await chrome.storage.local.set({ [key]: record })
  finish()
})

async function finish() {
  stop()
  await chrome.runtime.sendMessage({ type: 'focusTab', tab: params.get('tab') }).catch(() => {})
  const me = await chrome.tabs.getCurrent()
  if (me) chrome.tabs.remove(me.id)
  else window.close()
}
